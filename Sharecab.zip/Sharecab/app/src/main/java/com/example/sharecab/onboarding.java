package com.example.sharecab;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class onboarding extends AppCompatActivity {

   ViewPager viewPager;
   pageadapter slide;

   TextView skip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        setContentView(R.layout.activity_onboarding);
        skip = findViewById(R.id.skip);

          viewPager = findViewById(R.id.viewPager);
          slide = new pageadapter(onboarding.this);

          viewPager.setAdapter(slide);


          skip.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  startActivity(new Intent(onboarding.this, login.class));
              }
          });

    }




}
